This examples directory shows some examples written in Perl.

You can also test the command files by running from the command line.