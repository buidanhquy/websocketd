This examples directory shows some examples written in VBScript
that can be run using Windows Script Hosting.

Note that each .vbs file, also requires a .cmd file to launch it.
The WebSocket should connect to ws://..../[example].cmd.

http://en.wikipedia.org/wiki/Windows_Script_Host

You can also test the command files by running from the command line.