## Swift examples

### Count

Run the following line and open "html/count.html" from the websocketd examples directory.

```
$ websocketd --port=8080 count.swift
```

### Greeter

Run the following line and open "http://localhost:8080" in your browser to interact with the greeter server.

```
$ websocketd --port=8080 --devconsole greeter.swift 
```
