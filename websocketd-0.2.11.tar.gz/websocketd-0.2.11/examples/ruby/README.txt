This examples directory shows some examples written in Ruby.

You can also test the command files by running from the command line.