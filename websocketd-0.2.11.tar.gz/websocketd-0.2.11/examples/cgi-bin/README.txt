This examples directory shows how websocketd can also serve CGI scripts via HTTP.

$ websocketd --port=1234 --cgidir=examples/cgi-bin
# Then access http://localhost:1234/dump-env.sh


You can also test the command files by running from the command line.

